                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1685051
Respirator Pre Filter by selmo is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a pre-filter for a respirator -- it is designed to catch larger particles / dust in a coarse filter media so the (more expensive) carbon / VOC filters last longer.  It slides over a standard MSA respirator cartridge.

# Print Settings


Notes: 
I printed in ABS 
PLA may not be flexible enough to snap the grilles on / off 

# Post-Printing

1. Remove the respirator cartridges from the mask
2. Insert large box over cartridge
3. Attach cartridge to mask -- box will be loose
4. Stuff air filter media into box -- the filter media should be somewhat compressed and fill the volume of the box.  I used 4x12" heating duct vent filters, trimmed and folded over.   
5. Snap on grille -- the filter media will push against the respirator cartridge so the pre-filter is no longer loose.
6. Repeat for other side, if necessary.

Replace filter media when it's clogged.